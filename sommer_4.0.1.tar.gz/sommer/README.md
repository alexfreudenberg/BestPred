# sommer

To install this source on your computer type in the R terminal

library(devtools)

install_github('covaruber/sommer')
